

## Official Android device control

`plugins/with-jarvis-accessibility.ts` генерирует native `AccessibilityService`, его config XML и React Native bridge при Expo prebuild. Service используется только после явного включения пользователем в Android Settings. Bridge предоставляет global actions Back/Home/Recents/Notifications и вставку текста в сфокусированный editable node через `ACTION_SET_TEXT`. JARVIS не получает root-доступ, не обходит permission dialogs и не обещает контроль над защищёнными полями или приложениями, которые скрывают accessibility nodes.

Target device: Infinix SMART 10 / X6725, Android 15, XOS 15.1.2.195, UMS9230E/T7250, 4 GB RAM, 128 GB storage, 720×1600, 5000 mAh. UI и native voice defaults должны оставаться компактными: bounded buffers, небольшие quantized models, без тяжёлых постоянных анимаций и без автоматической отправки сообщений.
