# Offline Android voice research

- whisper.rn official repository: https://github.com/mybigday/whisper.rn
  - React Native binding for whisper.cpp.
  - Expo requires prebuild/native build.
  - RealtimeTranscriber supports PCM adapter, VAD, speech slices and long-running memory limits.
  - Android prebuilt libraries or source build are supported; Hexagon NPU is experimental on compatible Snapdragon devices.

- Porcupine React Native official docs: https://picovoice.ai/docs/quick-start/porcupine-react-native/
  - Wake word detection is on-device/offline.
  - Requires a Picovoice AccessKey.
  - Custom wake words use .ppn files; non-English wake words require the corresponding .pv model.

- Porcupine npm README: https://www.npmjs.com/package/@picovoice/porcupine-react-native
  - Android custom keyword files are bundled into Android assets.
  - Porcupine requires @picovoice/react-native-voice-processor for microphone frames.

- Android 14 foreground service types: https://developer.android.com/about/versions/14/changes/fgs-types-required
  - Microphone service must declare foregroundServiceType=microphone and FOREGROUND_SERVICE_MICROPHONE.
  - RECORD_AUDIO must be granted before starting the service.
  - Android can reject a microphone FGS started from background; start it from a visible activity.

- Android 11 foreground service restrictions: https://developer.android.com/about/versions/11/privacy/foreground-services
  - A background-started foreground service cannot access microphone/camera under while-in-use restrictions.

- Android background execution/wake locks: https://developer.android.com/media/platform/mediaplayer/background
  - Long-running work needs a foreground service and notification.
  - Wake locks must be used sparingly and released when no longer needed because they reduce battery life.
