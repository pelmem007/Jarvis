declare module "whisper.rn" {
  export function initWhisper(options: { filePath: string; useGpu?: boolean; useFlashAttn?: boolean }): Promise<any>;
}

declare module "whisper.rn/realtime-transcription" {
  export const RealtimeTranscriber: any;
}

declare module "whisper.rn/realtime-transcription/adapters" {
  export const AudioPcmStreamAdapter: any;
}

declare module "react-native-background-actions" {
  const BackgroundService: any;
  export default BackgroundService;
}
