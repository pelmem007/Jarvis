import { describe, expect, it } from "vitest";
import { bestFuzzyMatch, levenshteinDistance, normalizeCommand, normalizedDistance } from "../lib/levenshtein";

describe("Levenshtein distance", () => {
  it("counts insertions, deletions and substitutions", () => {
    expect(levenshteinDistance("kitten", "sitting")).toBe(3);
    expect(levenshteinDistance("план", "план")).toBe(0);
    expect(levenshteinDistance("", "jarvis")).toBe(6);
  });

  it("normalizes Russian voice input", () => {
    expect(normalizeCommand("  Ёлка!!!  ")).toBe("елка");
    expect(normalizedDistance("план на дню", "План на день")).toBeLessThan(0.3);
  });

  it("finds a command despite a small recognition typo", () => {
    const result = bestFuzzyMatch("составь план на дню", [
      { label: "План на день", aliases: ["составь план"] },
      { label: "Идея", aliases: ["дай идею"] },
    ]);
    expect(result?.label).toBe("План на день");
  });
});
