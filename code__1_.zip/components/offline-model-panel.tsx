import { MaterialIcons } from "@expo/vector-icons";
import { useState } from "react";
import { ActivityIndicator, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import type { OfflineModel } from "@/lib/local-llm";
import { formatModelSize } from "@/lib/local-llm";

type Props = {
  models: OfflineModel[];
  selectedModel: OfflineModel | null;
  enabled: boolean;
  importing: boolean;
  onToggle: () => void;
  onImport: () => void;
  onSelect: (model: OfflineModel) => void;
};

export function OfflineModelPanel({ models, selectedModel, enabled, importing, onToggle, onImport, onSelect }: Props) {
  const [expanded, setExpanded] = useState(false);
  const nativeReady = Platform.OS !== "web";
  return (
    <View style={styles.card}>
      <Pressable onPress={() => setExpanded((value) => !value)} style={styles.header}>
        <View style={styles.titleRow}><View style={styles.icon}><MaterialIcons name="memory" size={18} color="#BCA7FF" /></View><View><Text style={styles.title}>OFFLINE ENGINE</Text><Text style={styles.caption}>{nativeReady ? "GGUF // LLAMA.CPP // DEVICE" : "WEB FALLBACK // SERVER AI"}</Text></View></View>
        <View style={styles.headerRight}><View style={[styles.dot, { backgroundColor: enabled && selectedModel ? "#74E4B1" : "#566078" }]} /><MaterialIcons name={expanded ? "expand-less" : "expand-more"} size={20} color="#71809A" /></View>
      </Pressable>
      <View style={styles.selectedRow}><View style={styles.selectedCopy}><Text style={styles.selectedLabel}>{enabled && selectedModel ? "ЛОКАЛЬНАЯ МОДЕЛЬ" : "СЕРВЕРНЫЙ AI"}</Text><Text style={styles.selectedName} numberOfLines={1}>{selectedModel?.name ?? "Модель GGUF ещё не импортирована"}</Text></View><Pressable onPress={onToggle} disabled={!selectedModel} style={[styles.toggle, enabled && selectedModel && styles.toggleOn]}><Text style={[styles.toggleText, enabled && selectedModel && styles.toggleTextOn]}>{enabled && selectedModel ? "ON" : "OFF"}</Text></Pressable></View>
      {expanded && <View style={styles.expanded}><Text style={styles.description}>Импортируйте совместимый GGUF-файл от 50 MB до нескольких GB. Модель хранится на устройстве и отвечает без сети. Слишком большие модели могут не поместиться в RAM телефона.</Text><Pressable onPress={onImport} disabled={importing} style={({ pressed }) => [styles.importButton, pressed && styles.pressed]}>{importing ? <ActivityIndicator size="small" color="#070A12" /> : <MaterialIcons name="file-upload" size={17} color="#070A12" />}<Text style={styles.importText}>{importing ? "ИМПОРТИРУЮ…" : "ИМПОРТИРОВАТЬ .GGUF"}</Text></Pressable>{models.map((model) => <Pressable key={model.id} onPress={() => onSelect(model)} style={[styles.modelRow, selectedModel?.id === model.id && styles.modelSelected]}><MaterialIcons name={selectedModel?.id === model.id ? "radio-button-checked" : "radio-button-unchecked"} size={17} color={selectedModel?.id === model.id ? "#76F7FF" : "#5B6880"} /><View style={styles.modelCopy}><Text style={styles.modelName} numberOfLines={1}>{model.name}</Text><Text style={styles.modelMeta}>{formatModelSize(model.sizeBytes)}{model.architecture ? ` // ${model.architecture}` : ""}</Text></View></Pressable>)}</View>}
    </View>
  );
}

const styles = StyleSheet.create({ card: { borderWidth: 1, borderColor: "#292747", backgroundColor: "#0D1020", borderRadius: 16, padding: 14, gap: 12 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, titleRow: { flexDirection: "row", alignItems: "center", gap: 10 }, icon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#231F43" }, title: { color: "#D7D0FF", fontSize: 10, fontWeight: "700", letterSpacing: 1.4 }, caption: { color: "#67647F", fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), fontSize: 8, letterSpacing: 0.8, marginTop: 4 }, headerRight: { flexDirection: "row", alignItems: "center", gap: 8 }, dot: { width: 7, height: 7, borderRadius: 4 }, selectedRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, selectedCopy: { flex: 1 }, selectedLabel: { color: "#68758C", fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), fontSize: 8, letterSpacing: 1.2 }, selectedName: { color: "#D8E1F0", fontSize: 13, marginTop: 4 }, toggle: { borderWidth: 1, borderColor: "#2A344D", borderRadius: 14, paddingHorizontal: 11, paddingVertical: 6, backgroundColor: "#111827" }, toggleOn: { borderColor: "#4B897D", backgroundColor: "#16352F" }, toggleText: { color: "#6A7890", fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), fontSize: 9, letterSpacing: 1 }, toggleTextOn: { color: "#74E4B1" }, expanded: { borderTopWidth: 1, borderTopColor: "#20253D", paddingTop: 12, gap: 10 }, description: { color: "#7A879C", fontSize: 11, lineHeight: 16 }, importButton: { minHeight: 42, borderRadius: 12, backgroundColor: "#BCA7FF", flexDirection: "row", gap: 8, alignItems: "center", justifyContent: "center" }, importText: { color: "#070A12", fontSize: 10, fontWeight: "800", letterSpacing: 1.1 }, modelRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 8, paddingHorizontal: 7, borderRadius: 10 }, modelSelected: { backgroundColor: "#111A2D" }, modelCopy: { flex: 1 }, modelName: { color: "#C5D0E2", fontSize: 12 }, modelMeta: { color: "#64718A", fontSize: 9, marginTop: 3, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }) }, pressed: { opacity: 0.72 } });
