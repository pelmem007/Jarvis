import { z } from "zod";
import { getSessionCookieName, getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const assistantHistorySchema = z.array(z.object({ role: z.enum(["user", "assistant"]), text: z.string().trim().min(1).max(4000) })).max(12);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  assistant: router({
    ask: publicProcedure.input(z.object({ message: z.string().trim().min(1, "Команда не должна быть пустой").max(4000), history: assistantHistorySchema.default([]) })).mutation(async ({ input }) => {
      const result = await invokeLLM({
        messages: [
          { role: "system", content: "Ты JARVIS — спокойный, точный и полезный русскоязычный AI-ассистент. Отвечай на русском, коротко и естественно, обычно 1–4 предложениями. Не выдумывай доступ к функциям телефона, которых у тебя нет. Если запрос требует внешнего действия, объясни ограничение и предложи ближайший безопасный шаг. Не используй Markdown-заголовки и не обращайся к пользователю слишком фамильярно." },
          ...input.history.map((item) => ({ role: item.role, content: item.text })),
          { role: "user" as const, content: input.message },
        ],
        max_tokens: 350,
      });
      const rawContent = result.choices?.[0]?.message?.content;
      const text = Array.isArray(rawContent) ? rawContent.filter((part): part is { type: "text"; text: string } => part.type === "text").map((part) => part.text).join(" ").trim() : typeof rawContent === "string" ? rawContent.trim() : "";
      if (!text) throw new Error("JARVIS не вернул текстовый ответ");
      return { text };
    }),
  }),
});

export type AppRouter = typeof appRouter;
