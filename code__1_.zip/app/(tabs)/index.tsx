import { MaterialIcons } from "@expo/vector-icons";
import * as Speech from "expo-speech";
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from "expo-speech-recognition";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Animated, Easing, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, useWindowDimensions, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { OfflineModelPanel } from "@/components/offline-model-panel";
import { WakeWordPanel } from "@/components/wake-word-panel";
import { DeviceControlPanel } from "@/components/device-control-panel";
import { SmartSystemsPanel } from "@/components/smart-systems-panel";
import { CameraToolsPanel } from "@/components/camera-tools-panel";
import { ScreenContainer } from "@/components/screen-container";
import { bestFuzzyMatch, normalizeCommand } from "@/lib/levenshtein";
import { completeWithOfflineModel, loadStoredOfflineModels, pickAndRegisterGgufModel, type OfflineModel } from "@/lib/local-llm";
import { loadStoredWhisperModels, pickAndRegisterWhisperModel, startWhisperWakeService, stopWhisperWakeService, type WhisperModel } from "@/lib/offline-speech";
import { trpc } from "@/lib/trpc";
import { adjustAndroidVolume, isAccessibilityEnabled, launchKnownApp, openAccessibilitySettings, openAndroidSystemPanel, performAndroidGlobalAction, setAndroidTorch, typeIntoFocusedField } from "@/lib/accessibility";
import { collectDiagnostics, openBatteryOptimizationSettings, type Diagnostics } from "@/lib/device-diagnostics";
import { parseAndScheduleReminder } from "@/lib/automation";
import { listActions, listMemories, listNotes, logAction, parseMemorySearchCommand, parseNoteCommand, parseRememberCommand, rememberFact, saveLocalNote, searchMemory, searchNotes, type LocalNote, type MemoryItem } from "@/lib/smart-memory";

type AssistantStatus = "idle" | "listening" | "thinking" | "speaking" | "error";
type Message = { id: string; role: "user" | "assistant"; text: string };
type QuickCommand = { label: string; hint: string; icon: keyof typeof MaterialIcons.glyphMap; prompt: string; aliases?: string[] };

const quickCommands: QuickCommand[] = [
  { label: "План на день", hint: "Собрать фокус", icon: "today", aliases: ["план на сегодня", "составь план", "план на дню"], prompt: "Помоги составить короткий план на день из трёх приоритетов." },
  { label: "Идея", hint: "Разогреть мысли", icon: "lightbulb-outline", aliases: ["придумай идею", "дай идею"], prompt: "Предложи одну сильную идею, которая поможет мне начать важную задачу сегодня." },
  { label: "Объясни", hint: "Просто и ясно", icon: "auto-awesome", aliases: ["объясни мне", "расскажи проще"], prompt: "Объясни простыми словами, почему полезно разбивать большую задачу на маленькие шаги." },
];

const statusCopy: Record<AssistantStatus, { label: string; sublabel: string; color: string; icon: keyof typeof MaterialIcons.glyphMap }> = {
  idle: { label: "ГОТОВ К КОМАНДЕ", sublabel: "Нажмите на ядро и говорите", color: "#76F7FF", icon: "mic-none" },
  listening: { label: "СЛУШАЮ", sublabel: "Говорите, я здесь", color: "#76F7FF", icon: "graphic-eq" },
  thinking: { label: "ОБРАБАТЫВАЮ", sublabel: "Сверяю контекст запроса", color: "#BCA7FF", icon: "auto-awesome" },
  speaking: { label: "ОТВЕЧАЮ", sublabel: "Ответ готов", color: "#76F7FF", icon: "volume-up" },
  error: { label: "НУЖНО ВНИМАНИЕ", sublabel: "Проверьте соединение или доступ", color: "#FFB36B", icon: "error-outline" },
};

function formatTime() {
  return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date());
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const ask = trpc.assistant.ask.useMutation();
  const [status, setStatus] = useState<AssistantStatus>("idle");
  const [draft, setDraft] = useState("");
  const [transcript, setTranscript] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [lastAnswer, setLastAnswer] = useState("");
  const [messages, setMessages] = useState<Message[]>([{ id: "boot", role: "assistant", text: "Система в норме. Я готов к вашим командам." }]);
  const [offlineModels, setOfflineModels] = useState<OfflineModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<OfflineModel | null>(null);
  const [offlineEnabled, setOfflineEnabled] = useState(false);
  const [importingModel, setImportingModel] = useState(false);
  const [selectedWhisperModel, setSelectedWhisperModel] = useState<WhisperModel | null>(null);
  const [wakeWordRunning, setWakeWordRunning] = useState(false);
  const [importingWhisper, setImportingWhisper] = useState(false);
  const [accessibilityEnabled, setAccessibilityEnabled] = useState(false);
  const [deviceText, setDeviceText] = useState("");
  const [deviceBusy, setDeviceBusy] = useState(false);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [notes, setNotes] = useState<LocalNote[]>([]);
  const [actionCount, setActionCount] = useState(0);
  const [diagnostics, setDiagnostics] = useState<Diagnostics | null>(null);
  const [systemBusy, setSystemBusy] = useState(false);
  const [pulse] = useState(() => new Animated.Value(0));
  const isSubmitting = useRef(false);
  const scrollRef = useRef<ScrollView>(null);
  const activeMeta = statusCopy[status];

  useEffect(() => {
    const animation = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: status === "listening" ? 620 : 1500, easing: Easing.inOut(Easing.quad), useNativeDriver: Platform.OS !== "web" }),
      Animated.timing(pulse, { toValue: 0, duration: status === "listening" ? 620 : 1500, easing: Easing.inOut(Easing.quad), useNativeDriver: Platform.OS !== "web" }),
    ]));
    animation.start();
    return () => animation.stop();
  }, [pulse, status]);

  useEffect(() => {
    const timer = setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
    return () => clearTimeout(timer);
  }, [messages.length]);

  useEffect(() => {
    let mounted = true;
    void loadStoredOfflineModels().then((stored) => {
      if (!mounted) return;
      setOfflineModels(stored);
      setSelectedModel(stored[0] ?? null);
    });
    void loadStoredWhisperModels().then((stored) => {
      if (!mounted) return;
      setSelectedWhisperModel(stored[0] ?? null);
    });
    void isAccessibilityEnabled().then((enabled) => { if (mounted) setAccessibilityEnabled(enabled); });
    void Promise.all([listMemories(), listNotes(), listActions(), collectDiagnostics()]).then(([savedMemories, savedNotes, savedActions, deviceDiagnostics]) => { if (!mounted) return; setMemories(savedMemories); setNotes(savedNotes); setActionCount(savedActions.length); setDiagnostics(deviceDiagnostics); });
    return () => { mounted = false; };
  }, []);

  const speak = useCallback((text: string) => {
    if (Platform.OS === "web") { setStatus("idle"); return; }
    setStatus("speaking");
    Speech.stop();
    Speech.speak(text, { language: "ru-RU", rate: 0.94, pitch: 0.96, onDone: () => setStatus("idle"), onStopped: () => setStatus("idle"), onError: () => setStatus("idle") });
  }, []);

  const submit = useCallback(async (value: string) => {
    const message = value.trim();
    if (!message || isSubmitting.current) return;
    isSubmitting.current = true;
    setErrorMessage("");
    setTranscript(message);
    setDraft("");
    setStatus("thinking");
    setMessages((current) => [...current, { id: `user-${Date.now()}`, role: "user", text: message }]);
    try {
      const matchedCommand = bestFuzzyMatch(message, quickCommands);
      const remembered = parseRememberCommand(message);
      if (remembered) { const item = await rememberFact(remembered, "fact"); setMemories((current) => [item, ...current.filter((entry) => entry.id !== item.id)].slice(0, 100)); await logAction(`Запомнил: ${remembered}`, "ok", "JARVIS"); setActionCount((value) => value + 1); setLastAnswer("Запомнил это локально на телефоне."); setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: "Запомнил это локально на телефоне." }]); setStatus("idle"); return; }
      const note = parseNoteCommand(message);
      if (note) { const saved = await saveLocalNote(note); setNotes((current) => [saved, ...current].slice(0, 200)); await logAction("Создал локальную заметку", "ok", "JARVIS"); setActionCount((value) => value + 1); setLastAnswer("Заметка сохранена локально."); setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: "Заметка сохранена локально." }]); setStatus("idle"); return; }
      const memorySearch = parseMemorySearchCommand(message);
      if (memorySearch) { const [foundMemories, foundNotes] = await Promise.all([searchMemory(memorySearch), searchNotes(memorySearch)]); const result = [...foundMemories.map((item) => `Память: ${item.text}`), ...foundNotes.map((item) => `Заметка: ${item.text}`)].slice(0, 5); const answer = result.length ? result.join("\n") : "Ничего не нашёл в локальной памяти."; setLastAnswer(answer); setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: answer }]); setStatus("idle"); return; }
      const reminder = await parseAndScheduleReminder(message);
      if (reminder) { await logAction("Запланировал локальное напоминание", "ok", "JARVIS"); setActionCount((value) => value + 1); setLastAnswer("Напоминание запланировано локально."); setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: "Напоминание запланировано локально." }]); setStatus("idle"); return; }
      const normalized = normalizeCommand(message);
      const globalAction = normalized === "назад" ? 1 : normalized === "домой" || normalized === "на главный экран" ? 2 : normalized === "последние приложения" || normalized === "открой последние" ? 3 : normalized === "уведомления" || normalized === "открой уведомления" ? 4 : 0;
      const appPackages: Record<string, string> = { telegram: "org.telegram.messenger", телеграм: "org.telegram.messenger", whatsapp: "com.whatsapp", ватсап: "com.whatsapp", instagram: "com.instagram.android", инстаграм: "com.instagram.android", youtube: "com.google.android.youtube", ютуб: "com.google.android.youtube" };
      const appMatch = normalized.match(/^открой (telegram|телеграм|whatsapp|ватсап|instagram|инстаграм|youtube|ютуб)$/);
      if (appMatch) { const opened = await launchKnownApp(appPackages[appMatch[1]]); if (!opened) throw new Error("APP_NOT_INSTALLED"); setLastAnswer(`Открываю ${appMatch[1]}.`); setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: `Открываю ${appMatch[1]}.` }]); setStatus("idle"); return; }
      if (["включи фонарик", "выключи фонарик"].includes(normalized)) { const ok = await setAndroidTorch(normalized === "включи фонарик"); if (!ok) throw new Error("SYSTEM_ACTION_FAILED"); setLastAnswer("Готово."); setStatus("idle"); return; }
      if (["громче", "сделай громче", "тише", "сделай тише"].includes(normalized)) { const ok = await adjustAndroidVolume(["громче", "сделай громче"].includes(normalized)); if (!ok) throw new Error("SYSTEM_ACTION_FAILED"); setLastAnswer("Громкость изменена."); setStatus("idle"); return; }
      if (normalized === "открой wifi" || normalized === "открой вай фай") { await openAndroidSystemPanel("wifi"); setStatus("idle"); return; }
      if (normalized === "открой bluetooth" || normalized === "открой блютуз") { await openAndroidSystemPanel("bluetooth"); setStatus("idle"); return; }
      if (normalized === "открой яркость") { await openAndroidSystemPanel("brightness"); setStatus("idle"); return; }
      if (globalAction) {
        const enabled = await isAccessibilityEnabled();
        setAccessibilityEnabled(enabled);
        if (!enabled) throw new Error("ACCESSIBILITY_REQUIRED");
        const executed = await performAndroidGlobalAction(globalAction);
        if (!executed) throw new Error("ACCESSIBILITY_ACTION_FAILED");
        const actionAnswer = globalAction === 1 ? "Возвращаюсь назад." : globalAction === 2 ? "Открываю главный экран." : globalAction === 3 ? "Открываю последние приложения." : "Открываю уведомления.";
        setLastAnswer(actionAnswer);
        setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: actionAnswer }]);
        setStatus("idle");
        return;
      }
      const typeMatch = message.match(/^(?:напиши|введи|набери|вставь)\s+(.+)$/i);
      if (typeMatch) {
        const enabled = await isAccessibilityEnabled();
        setAccessibilityEnabled(enabled);
        if (!enabled) throw new Error("ACCESSIBILITY_REQUIRED");
        const inserted = await typeIntoFocusedField(typeMatch[1]);
        if (!inserted) throw new Error("TEXT_FIELD_NOT_READY");
        setLastAnswer("Текст вставлен в активное поле.");
        setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: "Текст вставлен в активное поле." }]);
        setStatus("idle");
        return;
      }
      const effectiveMessage = matchedCommand?.prompt ?? message;
      const history = messages.slice(-8).map(({ role, text }) => ({ role, text }));
      const answer = offlineEnabled && selectedModel && Platform.OS !== "web"
        ? await completeWithOfflineModel(selectedModel, history, effectiveMessage)
        : (await ask.mutateAsync({ message: effectiveMessage, history })).text.trim();
      setLastAnswer(answer);
      setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: "assistant", text: answer }]);
      speak(answer);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : "Не удалось связаться с JARVIS.";
      setErrorMessage(error instanceof Error && error.message === "ACCESSIBILITY_REQUIRED" ? "Включите JARVIS в настройках специальных возможностей Android." : error instanceof Error && error.message === "TEXT_FIELD_NOT_READY" ? "Сначала откройте приложение и поставьте курсор в текстовое поле." : error instanceof Error && error.message === "ACCESSIBILITY_ACTION_FAILED" ? "Android не разрешил это действие в текущем состоянии экрана." : error instanceof Error && error.message === "APP_NOT_INSTALLED" ? "Это приложение не установлено." : error instanceof Error && error.message === "SYSTEM_ACTION_FAILED" ? "Системное действие не поддержано телефоном." : "Нет соединения. Проверьте сеть и повторите запрос.");
      setStatus("error");
      setMessages((current) => [...current, { id: `error-${Date.now()}`, role: "assistant", text: messageText.includes("не вернул") ? "Я не получил ответ. Повторите команду ещё раз." : "Я временно недоступен. Повторите команду, когда соединение восстановится." }]);
    } finally {
      isSubmitting.current = false;
    }
  }, [ask, messages, offlineEnabled, selectedModel, speak]);

  useSpeechRecognitionEvent("start", () => { setErrorMessage(""); setStatus("listening"); });
  useSpeechRecognitionEvent("result", (event) => {
    const text = event.results?.[0]?.transcript?.trim() ?? "";
    if (!text) return;
    setTranscript(text);
    setDraft(text);
    if (event.isFinal) void submit(text);
  });
  useSpeechRecognitionEvent("end", () => { setStatus((current) => (current === "listening" ? "idle" : current)); });
  useSpeechRecognitionEvent("error", (event) => {
    if (event.error === "aborted") return;
    setErrorMessage(event.error === "not-allowed" ? "Разрешите доступ к микрофону в настройках телефона." : "Не удалось распознать речь. Попробуйте ещё раз.");
    setStatus("error");
  });

  const toggleListening = useCallback(async () => {
    if (status === "speaking") { if (Platform.OS !== "web") Speech.stop(); setStatus("idle"); return; }
    if (status === "listening") { ExpoSpeechRecognitionModule.stop(); return; }
    if (status === "thinking") return;
    try {
      const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!permission.granted) { setErrorMessage("Разрешите доступ к микрофону в настройках телефона."); setStatus("error"); return; }
      setTranscript(""); setDraft(""); setErrorMessage("");
      ExpoSpeechRecognitionModule.start({ lang: "ru-RU", interimResults: true, continuous: false, addsPunctuation: true, maxAlternatives: 1, contextualStrings: ["JARVIS", "ассистент", "план на день", "напомни", "объясни"] });
    } catch {
      setErrorMessage("Голосовой модуль недоступен. Используйте строку команды ниже.");
      setStatus("error");
    }
  }, [status]);

  const stopSpeaking = useCallback(() => { if (Platform.OS !== "web") Speech.stop(); setStatus("idle"); }, []);

  const importModel = useCallback(async () => {
    setImportingModel(true);
    try {
      const model = await pickAndRegisterGgufModel();
      if (model) { setOfflineModels((current) => [model, ...current.filter((item) => item.id !== model.id)]); setSelectedModel(model); setOfflineEnabled(Platform.OS !== "web"); }
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Не удалось импортировать GGUF-модель.");
      setStatus("error");
    } finally { setImportingModel(false); }
  }, []);

  const importWhisperModel = useCallback(async () => {
    setImportingWhisper(true);
    try {
      const model = await pickAndRegisterWhisperModel();
      if (model) setSelectedWhisperModel(model);
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Не удалось импортировать Whisper-модель.");
      setStatus("error");
    } finally { setImportingWhisper(false); }
  }, []);


  const refreshDiagnostics = useCallback(async () => { setSystemBusy(true); setDiagnostics(await collectDiagnostics()); setSystemBusy(false); }, []);
  const handleRemember = useCallback(async (text: string) => { const item = await rememberFact(text, "fact"); setMemories((current) => [item, ...current.filter((entry) => entry.id !== item.id)].slice(0, 100)); await logAction("Сохранил локальный факт", "ok", "JARVIS"); setActionCount((value) => value + 1); }, []);
  const handleNote = useCallback(async (text: string) => { const note = await saveLocalNote(text); setNotes((current) => [note, ...current].slice(0, 200)); await logAction("Сохранил локальную заметку", "ok", "JARVIS"); setActionCount((value) => value + 1); }, []);
  const handleSearch = useCallback(async (query: string) => { const [foundMemories, foundNotes] = await Promise.all([searchMemory(query), searchNotes(query)]); const answer = [...foundMemories.map((item) => `Память: ${item.text}`), ...foundNotes.map((item) => `Заметка: ${item.text}`)].slice(0, 5).join("\n") || "Ничего не найдено локально."; setTranscript(answer); setStatus("idle"); }, []);
  const handleReminder = useCallback(async (text: string) => { setSystemBusy(true); try { const scheduled = await parseAndScheduleReminder(text); if (!scheduled) throw new Error("Пример: напомни через 20 минут о встрече"); await logAction("Создал напоминание", "ok", "JARVIS"); setActionCount((value) => value + 1); setLastAnswer("Напоминание запланировано локально."); } catch (error) { setErrorMessage(error instanceof Error ? error.message : "Не удалось создать напоминание."); setStatus("error"); } finally { setSystemBusy(false); } }, []);
  const stopAllServices = useCallback(async () => { await stopWhisperWakeService(); setWakeWordRunning(false); setStatus("idle"); await logAction("Остановил фоновые сервисы", "ok", "JARVIS"); setActionCount((value) => value + 1); }, []);

  const refreshAccessibility = useCallback(async () => { setAccessibilityEnabled(await isAccessibilityEnabled()); }, []);
  const insertDeviceText = useCallback(async () => {
    setDeviceBusy(true);
    const inserted = await typeIntoFocusedField(deviceText);
    setDeviceBusy(false);
    if (!inserted) { setErrorMessage("Не найдено активное текстовое поле. Откройте приложение и поставьте курсор."); setStatus("error"); }
  }, [deviceText]);
  const runGlobalAction = useCallback(async (action: number) => {
    const ok = await performAndroidGlobalAction(action);
    if (!ok) { setErrorMessage("Сначала включите Accessibility Service JARVIS."); setStatus("error"); }
  }, []);

  const toggleWakeWord = useCallback(async () => {
    if (wakeWordRunning) {
      await stopWhisperWakeService();
      setWakeWordRunning(false);
      setStatus("idle");
      return;
    }
    if (!selectedWhisperModel || Platform.OS === "web") return;
    try {
      const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!permission.granted) { setErrorMessage("Разрешите доступ к микрофону для always-on режима."); setStatus("error"); return; }
      await startWhisperWakeService(selectedWhisperModel, {
        onWakeWord: () => { setTranscript("Джарвис"); setStatus("listening"); },
        onCommand: (text) => { setTranscript(text); void submit(text); },
        onError: (message) => { setErrorMessage(message); setStatus("error"); },
      });
      setWakeWordRunning(true);
      setStatus("listening");
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Не удалось запустить offline wake word.");
      setStatus("error");
    }
  }, [selectedWhisperModel, submit, wakeWordRunning]);
  const statusColor = activeMeta.color;
  const coreSize = Math.min(214, Math.max(174, height * 0.24));
  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, status === "listening" ? 1.13 : 1.07] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.18, status === "listening" ? 0.48 : 0.32] });
  const recentMessages = useMemo(() => messages.slice(-4), [messages]);

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-[#070A12]" safeAreaClassName="bg-[#070A12]">
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView ref={scrollRef} style={styles.flex} contentContainerStyle={[styles.content, { paddingTop: Math.max(insets.top * 0.1, 8), paddingBottom: Math.max(insets.bottom, 16) }]} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <View><View style={styles.wordmarkRow}><View style={styles.signalDot} /><Text style={styles.wordmark}>JARVIS</Text></View><Text style={styles.headerMeta}>PERSONAL INTELLIGENCE // v1.0</Text></View>
            <View style={styles.onlinePill}><View style={styles.onlineDot} /><Text style={styles.onlineText}>ONLINE</Text></View>
          </View>

          <View style={styles.greetingBlock}><Text style={styles.eyebrow}>ГОЛОСОВОЙ КОМАНДНЫЙ ЦЕНТР</Text><Text style={styles.title}>Добрый день, командир.</Text><Text style={styles.subtitle}>Я рядом. Дайте мне задачу голосом или текстом.</Text></View>

          <OfflineModelPanel models={offlineModels} selectedModel={selectedModel} enabled={offlineEnabled} importing={importingModel} onToggle={() => setOfflineEnabled((value) => !value)} onImport={() => void importModel()} onSelect={setSelectedModel} />
          <WakeWordPanel model={selectedWhisperModel} running={wakeWordRunning} importing={importingWhisper} onImport={() => void importWhisperModel()} onToggle={() => void toggleWakeWord()} />
          <DeviceControlPanel enabled={accessibilityEnabled} text={deviceText} busy={deviceBusy} onChangeText={setDeviceText} onRefresh={() => void refreshAccessibility()} onOpenSettings={() => void openAccessibilitySettings()} onType={() => void insertDeviceText()} onAction={(action) => void runGlobalAction(action)} />
          <SmartSystemsPanel memories={memories} notes={notes} diagnostics={diagnostics} actionCount={actionCount} busy={systemBusy} onRemember={(text) => void handleRemember(text)} onNote={(text) => void handleNote(text)} onSearch={(query) => void handleSearch(query)} onReminder={(text) => void handleReminder(text)} onRefresh={() => void refreshDiagnostics()} onBatterySettings={() => void openBatteryOptimizationSettings()} onStopServices={() => void stopAllServices()} />
          <CameraToolsPanel />

          <View style={styles.coreSection}>
            <View style={[styles.orbitLine, { width: coreSize + 58, height: coreSize + 58, borderColor: `${statusColor}33` }]} />
            <Animated.View style={[styles.orbitLine, { width: coreSize + 30, height: coreSize + 30, borderColor: `${statusColor}70`, transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
            <View style={[styles.coreGlow, { width: coreSize + 18, height: coreSize + 18, backgroundColor: `${statusColor}12` }]} />
            <Pressable onPress={toggleListening} style={({ pressed }) => [styles.coreButton, { width: coreSize, height: coreSize, borderColor: `${statusColor}99`, transform: [{ scale: pressed ? 0.97 : 1 }] }]}>
              <View style={[styles.coreInner, { backgroundColor: `${statusColor}14` }]}><MaterialIcons name={activeMeta.icon} size={42} color={statusColor} /><Text style={[styles.coreLabel, { color: statusColor }]}>{status === "listening" ? "STOP" : status === "thinking" ? "WAIT" : "TAP"}</Text></View>
            </Pressable>
            <View style={styles.coreCaption}><View style={[styles.statusBar, { backgroundColor: statusColor }]} /><View><Text style={[styles.statusLabel, { color: statusColor }]}>{activeMeta.label}</Text><Text style={styles.statusSub}>{activeMeta.sublabel}</Text></View></View>
          </View>

          {Boolean(transcript || errorMessage) && <View style={[styles.transcriptCard, status === "error" && styles.errorCard]}><View style={styles.cardTopline}><Text style={styles.cardEyebrow}>{status === "error" ? "SYSTEM NOTE" : "LIVE TRANSCRIPT"}</Text><Text style={styles.cardTime}>{formatTime()}</Text></View><Text style={styles.transcriptText}>{errorMessage || `«${transcript}»`}</Text>{status === "error" && <Pressable onPress={() => { setErrorMessage(""); setStatus("idle"); }}><Text style={styles.retryText}>СБРОСИТЬ ОШИБКУ →</Text></Pressable>}</View>}

          <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>БЫСТРЫЕ КОМАНДЫ</Text><Text style={styles.sectionMeta}>ONE TAP</Text></View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quickRow}>{quickCommands.map((command) => <Pressable key={command.label} onPress={() => void submit(command.prompt)} style={({ pressed }) => [styles.quickCard, pressed && styles.pressed]}><View style={styles.quickIcon}><MaterialIcons name={command.icon} size={20} color="#76F7FF" /></View><Text style={styles.quickLabel}>{command.label}</Text><Text style={styles.quickHint}>{command.hint}</Text></Pressable>)}</ScrollView>

          <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>ТЕКУЩИЙ ДИАЛОГ</Text><Text style={styles.sectionMeta}>{messages.length.toString().padStart(2, "0")} MSG</Text></View>
          <View style={styles.historyCard}>{recentMessages.map((message, index) => <View key={message.id} style={[styles.messageRow, index > 0 && styles.messageDivider]}><View style={[styles.messageMarker, { backgroundColor: message.role === "assistant" ? "#76F7FF" : "#BCA7FF" }]} /><View style={styles.messageBody}><View style={styles.messageMeta}><Text style={styles.messageRole}>{message.role === "assistant" ? "JARVIS" : "YOU"}</Text><Text style={styles.messageTime}>{index === recentMessages.length - 1 ? "NOW" : "—"}</Text></View><Text style={styles.messageText}>{message.text}</Text></View></View>)}{Boolean(lastAnswer) && status !== "speaking" && <Pressable onPress={() => speak(lastAnswer)} style={styles.repeatButton}><MaterialIcons name="replay" size={16} color="#76F7FF" /><Text style={styles.repeatText}>ПОВТОРИТЬ ОТВЕТ</Text></Pressable>}{status === "speaking" && <Pressable onPress={stopSpeaking} style={styles.repeatButton}><MaterialIcons name="stop-circle" size={16} color="#FFB36B" /><Text style={[styles.repeatText, { color: "#FFB36B" }]}>ОСТАНОВИТЬ ОЗВУЧКУ</Text></Pressable>}</View>

          <View style={styles.composerRow}><TextInput value={draft} onChangeText={setDraft} onSubmitEditing={() => void submit(draft)} placeholder="Напишите команду…" placeholderTextColor="#566078" style={styles.input} returnKeyType="send" editable={status !== "thinking"} /><Pressable onPress={() => void submit(draft)} disabled={!draft.trim() || status === "thinking"} style={({ pressed }) => [styles.sendButton, (!draft.trim() || status === "thinking") && styles.sendDisabled, pressed && styles.pressed]}><MaterialIcons name="arrow-upward" size={22} color="#070A12" /></Pressable></View>
          <Text style={styles.footerHint}>Голосовой ввод: русский // Данные запроса защищены</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 }, content: { paddingHorizontal: 20, gap: 18 }, header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", paddingTop: 4 }, wordmarkRow: { flexDirection: "row", alignItems: "center", gap: 8 }, signalDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#76F7FF" }, wordmark: { color: "#F4F7FF", fontSize: 19, fontWeight: "800", letterSpacing: 5 }, headerMeta: { color: "#566078", fontSize: 8, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.5, marginTop: 6 }, onlinePill: { flexDirection: "row", alignItems: "center", gap: 7, borderWidth: 1, borderColor: "#22304A", borderRadius: 18, paddingHorizontal: 11, paddingVertical: 8, backgroundColor: "#0B1220" }, onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#74E4B1" }, onlineText: { color: "#9CB0C8", fontSize: 9, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.2 }, greetingBlock: { marginTop: 6, gap: 7 }, eyebrow: { color: "#65718A", fontSize: 10, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.4 }, title: { color: "#F4F7FF", fontSize: 29, fontWeight: "700", letterSpacing: -0.7 }, subtitle: { color: "#8995AA", fontSize: 14, lineHeight: 21, maxWidth: 320 }, coreSection: { minHeight: 292, alignItems: "center", justifyContent: "center", marginTop: -4 }, orbitLine: { position: "absolute", borderRadius: 999, borderWidth: 1, borderStyle: "dashed" }, coreGlow: { position: "absolute", borderRadius: 999 }, coreButton: { alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 999, backgroundColor: "#0B1220" }, coreInner: { width: "78%", height: "78%", borderRadius: 999, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#25344D" }, coreLabel: { fontSize: 10, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 2, marginTop: 9 }, coreCaption: { position: "absolute", bottom: 2, flexDirection: "row", alignItems: "center", gap: 10 }, statusBar: { width: 3, height: 32, borderRadius: 2 }, statusLabel: { fontSize: 11, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.3 }, statusSub: { color: "#68758C", fontSize: 12, marginTop: 4 }, transcriptCard: { borderWidth: 1, borderColor: "#26344D", backgroundColor: "#0C1423", borderRadius: 16, padding: 15, gap: 10 }, errorCard: { borderColor: "#694B37", backgroundColor: "#18131A" }, cardTopline: { flexDirection: "row", justifyContent: "space-between" }, cardEyebrow: { color: "#6C7B94", fontSize: 9, letterSpacing: 1.6, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }) }, cardTime: { color: "#48556D", fontSize: 9, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }) }, transcriptText: { color: "#D8E1F0", fontSize: 15, lineHeight: 22 }, retryText: { color: "#FFB36B", fontSize: 10, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.2 }, sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 2 }, sectionTitle: { color: "#B4C0D4", fontSize: 10, fontWeight: "700", letterSpacing: 1.8 }, sectionMeta: { color: "#566078", fontSize: 9, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1 }, quickRow: { gap: 10, paddingRight: 20 }, quickCard: { width: 132, minHeight: 111, borderRadius: 15, borderWidth: 1, borderColor: "#24334D", backgroundColor: "#0B1220", padding: 13, justifyContent: "space-between" }, quickIcon: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#10283A", alignItems: "center", justifyContent: "center" }, quickLabel: { color: "#EAF1FF", fontSize: 13, fontWeight: "700", marginTop: 10 }, quickHint: { color: "#68758C", fontSize: 11, marginTop: 3 }, historyCard: { borderRadius: 16, borderWidth: 1, borderColor: "#1E2B41", backgroundColor: "#0A111E", paddingHorizontal: 15, paddingVertical: 6 }, messageRow: { flexDirection: "row", gap: 12, paddingVertical: 13 }, messageDivider: { borderTopWidth: 1, borderTopColor: "#172238" }, messageMarker: { width: 3, borderRadius: 2, minHeight: 40, opacity: 0.9 }, messageBody: { flex: 1, gap: 5 }, messageMeta: { flexDirection: "row", justifyContent: "space-between" }, messageRole: { color: "#72809A", fontSize: 9, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.4 }, messageTime: { color: "#46526A", fontSize: 9, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }) }, messageText: { color: "#C4D0E2", fontSize: 13, lineHeight: 19 }, repeatButton: { flexDirection: "row", gap: 8, alignItems: "center", borderTopWidth: 1, borderTopColor: "#172238", paddingTop: 12, paddingBottom: 10 }, repeatText: { color: "#76F7FF", fontSize: 10, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 1.2 }, composerRow: { flexDirection: "row", gap: 10, alignItems: "center", marginTop: 2 }, input: { flex: 1, minHeight: 48, borderWidth: 1, borderColor: "#25334B", borderRadius: 15, color: "#EAF1FF", backgroundColor: "#0B1220", paddingHorizontal: 16, fontSize: 14 }, sendButton: { width: 48, height: 48, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#76F7FF" }, sendDisabled: { backgroundColor: "#223044" }, pressed: { opacity: 0.72 }, footerHint: { textAlign: "center", color: "#45526A", fontSize: 9, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), letterSpacing: 0.8, marginTop: -3 },
});
