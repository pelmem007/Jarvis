import { withAndroidManifest, withDangerousMod, type ConfigPlugin } from "@expo/config-plugins";
import fs from "node:fs";
import path from "node:path";

const withJarvisAccessibility: ConfigPlugin = (config) => {
  config = withAndroidManifest(config, (mod) => {
    const application = mod.modResults.manifest.application?.[0];
    if (!application) return mod;
    const services = application.service ?? (application.service = []);
    const name = ".JarvisAccessibilityService";
    if (!services.some((service) => service.$?.["android:name"] === name)) {
      services.push({ $: { "android:name": name, "android:permission": "android.permission.BIND_ACCESSIBILITY_SERVICE", "android:exported": "true", "android:label": "JARVIS Accessibility" }, "intent-filter": [{ action: [{ $: { "android:name": "android.accessibilityservice.AccessibilityService" } }] }], "meta-data": [{ $: { "android:name": "android.accessibilityservice", "android:resource": "@xml/jarvis_accessibility_config" } }] } as any);
    }
    return mod;
  });
  return withDangerousMod(config, ["android", async (mod) => {
    const root = mod.modRequest.projectRoot;
    const packageName = config.android?.package ?? "com.example.jarvis";
    const packagePath = packageName.replace(/\./g, "/");
    const javaDir = path.join(root, "android/app/src/main/java", packagePath);
    const xmlDir = path.join(root, "android/app/src/main/res/xml");
    fs.mkdirSync(javaDir, { recursive: true });
    fs.mkdirSync(xmlDir, { recursive: true });
    fs.writeFileSync(path.join(xmlDir, "jarvis_accessibility_config.xml"), `<?xml version="1.0" encoding="utf-8"?>\n<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android" android:accessibilityEventTypes="typeAllMask" android:accessibilityFeedbackType="feedbackGeneric" android:notificationTimeout="100" android:canRetrieveWindowContent="true" android:canPerformGestures="true" android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagReportViewIds" />\n`);
    const service = `package ${packageName};

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class JarvisAccessibilityService extends AccessibilityService {
  private static JarvisAccessibilityService instance;
  public static boolean typeIntoFocusedField(String text) {
    if (instance == null) return false;
    AccessibilityNodeInfo root = instance.getRootInActiveWindow();
    if (root == null) return false;
    AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    if (focused == null) focused = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
    if (focused == null || !focused.isEditable()) return false;
    Bundle args = new Bundle();
    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
    return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
  }
  public static boolean performGlobalActionFromModule(int action) { return instance != null && instance.performGlobalAction(action); }
  @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
  @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
  @Override public void onInterrupt() { }
  @Override public void onDestroy() { instance = null; super.onDestroy(); }
}
`;
    const module = `package ${packageName};

import android.content.Intent;
import android.content.Context;
import android.media.AudioManager;
import android.hardware.camera2.CameraManager;
import android.provider.Settings;
import android.text.TextUtils;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class JarvisAccessibilityModule extends ReactContextBaseJavaModule {
  private final ReactApplicationContext context;
  JarvisAccessibilityModule(ReactApplicationContext context) { super(context); this.context = context; }
  @Override public String getName() { return "JarvisAccessibility"; }
  @ReactMethod public void openSettings() { Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent); }
  @ReactMethod public void isEnabled(Promise promise) { promise.resolve(isServiceEnabled()); }
  @ReactMethod public void typeText(String text, Promise promise) { promise.resolve(JarvisAccessibilityService.typeIntoFocusedField(text)); }
  @ReactMethod public void globalAction(int action, Promise promise) { promise.resolve(JarvisAccessibilityService.performGlobalActionFromModule(action)); }
  @ReactMethod public void launchApp(String packageName, Promise promise) { try { Intent launch = context.getPackageManager().getLaunchIntentForPackage(packageName); if (launch == null) { promise.resolve(false); return; } launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(launch); promise.resolve(true); } catch (Exception error) { promise.resolve(false); } }
  @ReactMethod public void adjustVolume(boolean increase, Promise promise) { AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE); if (audio == null) { promise.resolve(false); return; } audio.adjustVolume(increase ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); promise.resolve(true); }
  @ReactMethod public void setTorch(boolean enabled, Promise promise) { try { CameraManager camera = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE); String[] cameras = camera == null ? new String[0] : camera.getCameraIdList(); if (camera == null || cameras.length == 0) { promise.resolve(false); return; } camera.setTorchMode(cameras[0], enabled); promise.resolve(true); } catch (Exception error) { promise.resolve(false); } }
  @ReactMethod public void openSystemPanel(String panel, Promise promise) { try { String action = Settings.ACTION_SETTINGS; if ("wifi".equals(panel)) action = "android.settings.panel.action.WIFI"; else if ("bluetooth".equals(panel)) action = "android.settings.panel.action.BLUETOOTH"; else if ("brightness".equals(panel)) action = Settings.ACTION_DISPLAY_SETTINGS; else if ("battery".equals(panel)) action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS; Intent intent = new Intent(action); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent); promise.resolve(true); } catch (Exception error) { promise.resolve(false); } }
  private boolean isServiceEnabled() {
    String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
    String expected = context.getPackageName() + "/" + JarvisAccessibilityService.class.getName();
    return !TextUtils.isEmpty(enabled) && enabled.contains(expected);
  }
}
`;
    const pkg = `package ${packageName};

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JarvisAccessibilityPackage implements ReactPackage {
  @Override public List<NativeModule> createNativeModules(ReactApplicationContext context) { return Collections.<NativeModule>singletonList(new JarvisAccessibilityModule(context)); }
  @Override public List<ViewManager> createViewManagers(ReactApplicationContext context) { return new ArrayList<>(); }
}
`;
    fs.writeFileSync(path.join(javaDir, "JarvisAccessibilityService.java"), service);
    fs.writeFileSync(path.join(javaDir, "JarvisAccessibilityModule.java"), module);
    fs.writeFileSync(path.join(javaDir, "JarvisAccessibilityPackage.java"), pkg);
    const applicationFile = path.join(javaDir, "MainApplication.kt");
    if (fs.existsSync(applicationFile)) {
      const current = fs.readFileSync(applicationFile, "utf8");
      const marker = "PackageList(this).packages.apply {";
      if (current.includes(marker) && !current.includes("add(JarvisAccessibilityPackage())")) fs.writeFileSync(applicationFile, current.replace(marker, `${marker}\n          add(JarvisAccessibilityPackage())`));
    }
    return mod;
  }]);
};

export default withJarvisAccessibility;
