import { withAndroidManifest, type ConfigPlugin } from "@expo/config-plugins";

const withJarvisForegroundService: ConfigPlugin = (config) => withAndroidManifest(config, (mod) => {
  const manifest = mod.modResults.manifest;
  const application = manifest.application?.[0];
  if (!application) return mod;
  const services = application.service ?? (application.service = []);
  const existing = services.find((service) => service.$?.["android:name"] === ".RNBackgroundActionsTask" || service.$?.["android:name"] === "com.asterinet.react.bgactions.RNBackgroundActionsTask");
  const service = existing ?? { $: { "android:name": "com.asterinet.react.bgactions.RNBackgroundActionsTask" } };
  service.$ = { ...service.$, "android:exported": "false", "android:foregroundServiceType": "microphone", "android:stopWithTask": "false" } as any;
  if (!existing) services.push(service);
  return mod;
});

export default withJarvisForegroundService;
