# JARVIS feature pack

## Локальная память и быстрые ответы
- [x] Факты и предпочтения хранятся локально в AsyncStorage; лимит — 100 memory items.
- [x] Локальные заметки хранятся на телефоне; лимит — 200 заметок.
- [x] Есть голосовые команды «запомни…», «создай заметку…», «найди в памяти…» и локальный поиск по прошлым сохранениям.
- [x] Action journal хранит последние 300 действий.
- [x] Offline GGUF response cache хранит до 128 ответов с TTL 7 дней.
- [x] Для 4 ГБ RAM задан CPU-first профиль: Qwen2.5-1.5B Q4_K_M как основной, Qwen2.5-0.5B Q4_K_M как FAST fallback, n_ctx 2048, короткий output, q8_0 KV-cache, n_parallel 1 и 4 CPU threads.
- [x] GPU/Hexagon offload не включается по умолчанию, потому что для Unisoc T7250 нет подтверждённого пути ускорения.

## Управление приложениями и устройством
- [x] Accessibility Service позволяет Back/Home/Recents/Notifications и ввод в сфокусированное поле.
- [x] Голосовой запуск Telegram, WhatsApp, Instagram и YouTube через Android PackageManager.
- [x] Голосовые команды изменения громкости и включения/выключения фонарика.
- [x] Открытие системных панелей Wi‑Fi, Bluetooth, яркости и battery settings.
- [x] Кнопка emergency stop отключает wake-word foreground service.
- [x] Все опасные действия требуют явного действия пользователя; автоматическая отправка сообщений, обход permission prompts и обход защищённых полей запрещены.

## Напоминания и журнал
- [x] Локальные уведомления для «напомни через N минут…».
- [x] Повторяющиеся напоминания через Expo Notifications и базовый weekday command parser.
- [x] Журналирует локальные memory/note/reminder/device actions.
- [ ] Location reminders, полноценный календарь, weather briefing и вечерний отчёт требуют отдельных разрешений/API и physical device validation.

## Камера и экран
- [x] Камера включается только вручную.
- [x] QR scanner panel на базе Expo Camera.
- [ ] Полный offline OCR/перевод/описание изображений требует отдельного ML Kit/vision native runtime; сейчас не заявляется как готовая функция.
- [ ] Копирование произвольного текста с экрана и поиск элементов доступны только там, где приложение отдаёт Accessibility nodes.

## Диагностика и target device
- [x] Панель показывает модель устройства, Android version, battery, charging, total RAM и network state.
- [x] Есть переход в Android Settings для battery optimization; XOS может потребовать ручное исключение JARVIS из battery saver/autostart restrictions.
- [x] Target profile: Infinix SMART 10 / X6725, Android 15, XOS 15.1.2.195, UMS9230E/T7250, 4 GB RAM, 128 GB, 720×1600, 5000 mAh.
- [ ] Проверить на физическом телефоне RSS/токены-секунду/нагрев/OOM и подобрать между Qwen 0.5B и 1.5B по измерениям.
- [ ] Выполнить native APK/AAB build и установить его на target device.
