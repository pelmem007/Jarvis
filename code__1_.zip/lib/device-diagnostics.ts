import * as Battery from "expo-battery";
import * as Device from "expo-device";
import * as Network from "expo-network";
import { Linking, Platform } from "react-native";

export type Diagnostics = { model: string; os: string; battery: number | null; charging: boolean | null; totalMemoryGb: number | null; network: string; xosNote: string; refreshedAt: number };

export async function collectDiagnostics(): Promise<Diagnostics> {
  const [battery, power, network] = await Promise.allSettled([Battery.getBatteryLevelAsync(), Battery.getPowerStateAsync(), Network.getNetworkStateAsync()]);
  const batteryValue = battery.status === "fulfilled" ? battery.value : null;
  const powerValue = power.status === "fulfilled" ? power.value : null;
  const networkValue = network.status === "fulfilled" ? network.value : null;
  return { model: Device.modelName ?? "Неизвестное устройство", os: `${Device.osName ?? Platform.OS} ${Device.osVersion ?? ""}`.trim(), battery: batteryValue === null ? null : Math.round(batteryValue * 100), charging: powerValue?.batteryState === Battery.BatteryState.CHARGING || powerValue?.batteryState === Battery.BatteryState.FULL, totalMemoryGb: Device.totalMemory ? Math.round(Device.totalMemory / 1024 / 1024 / 1024 * 10) / 10 : null, network: networkValue?.isConnected ? networkValue.type ?? "connected" : "offline", xosNote: "XOS может ограничивать фоновые процессы. Проверьте battery optimization для JARVIS.", refreshedAt: Date.now() };
}

export async function openBatteryOptimizationSettings() {
  if (Platform.OS !== "android") return;
  await Linking.openSettings();
}
