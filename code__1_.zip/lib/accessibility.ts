import { NativeModules, Platform } from "react-native";

const native = Platform.OS === "android" ? NativeModules.JarvisAccessibility : null;

export const AndroidGlobalAction = { back: 1, home: 2, recents: 3, notifications: 4 } as const;

export async function openAccessibilitySettings() {
  if (!native) return;
  native.openSettings();
}

export async function isAccessibilityEnabled(): Promise<boolean> {
  if (!native) return false;
  return Boolean(await native.isEnabled());
}

export async function typeIntoFocusedField(text: string): Promise<boolean> {
  if (!native || !text.trim()) return false;
  return Boolean(await native.typeText(text));
}

export async function performAndroidGlobalAction(action: number): Promise<boolean> {
  if (!native) return false;
  return Boolean(await native.globalAction(action));
}

export async function launchKnownApp(packageName: string): Promise<boolean> {
  if (!native) return false;
  return Boolean(await native.launchApp(packageName));
}

export async function adjustAndroidVolume(increase: boolean): Promise<boolean> {
  if (!native) return false;
  return Boolean(await native.adjustVolume(increase));
}

export async function setAndroidTorch(enabled: boolean): Promise<boolean> {
  if (!native) return false;
  return Boolean(await native.setTorch(enabled));
}

export async function openAndroidSystemPanel(panel: "wifi" | "bluetooth" | "brightness" | "battery"): Promise<boolean> {
  if (!native) return false;
  return Boolean(await native.openSystemPanel(panel));
}
