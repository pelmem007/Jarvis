import AsyncStorage from "@react-native-async-storage/async-storage";

export type MemoryItem = { id: string; kind: "preference" | "fact"; text: string; createdAt: number; updatedAt: number };
export type LocalNote = { id: string; text: string; createdAt: number; updatedAt: number };
export type ActionLog = { id: string; action: string; app?: string; result: "ok" | "blocked" | "error"; createdAt: number };

type CacheItem = { value: string; createdAt: number };
const KEYS = { memories: "jarvis.memory.items.v1", notes: "jarvis.memory.notes.v1", actions: "jarvis.memory.actions.v1", cache: "jarvis.memory.response-cache.v1" } as const;
const LIMITS = { memories: 100, notes: 200, actions: 300, cache: 128 } as const;

async function read<T>(key: string, fallback: T): Promise<T> { try { const raw = await AsyncStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; } catch { return fallback; } }
async function write<T>(key: string, value: T) { await AsyncStorage.setItem(key, JSON.stringify(value)); }
function id(prefix: string) { return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`; }

export async function listMemories() { return read<MemoryItem[]>(KEYS.memories, []); }
export async function rememberFact(text: string, kind: MemoryItem["kind"] = "fact") {
  const now = Date.now(); const current = await listMemories();
  const normalized = text.trim(); const existing = current.find((item) => item.text.toLowerCase() === normalized.toLowerCase());
  const item: MemoryItem = existing ? { ...existing, updatedAt: now } : { id: id("memory"), kind, text: normalized, createdAt: now, updatedAt: now };
  await write(KEYS.memories, [item, ...current.filter((entry) => entry.id !== existing?.id)].slice(0, LIMITS.memories));
  return item;
}
export async function forgetMemory(idToRemove: string) { const current = await listMemories(); await write(KEYS.memories, current.filter((item) => item.id !== idToRemove)); }
export async function searchMemory(query: string) { const q = query.trim().toLowerCase(); return (await listMemories()).filter((item) => !q || item.text.toLowerCase().includes(q)).slice(0, 20); }

export async function listNotes() { return read<LocalNote[]>(KEYS.notes, []); }
export async function saveLocalNote(text: string) { const now = Date.now(); const note: LocalNote = { id: id("note"), text: text.trim(), createdAt: now, updatedAt: now }; await write(KEYS.notes, [note, ...(await listNotes())].slice(0, LIMITS.notes)); return note; }
export async function searchNotes(query: string) { const q = query.trim().toLowerCase(); return (await listNotes()).filter((note) => !q || note.text.toLowerCase().includes(q)).slice(0, 30); }

export async function logAction(action: string, result: ActionLog["result"], app?: string) { const item: ActionLog = { id: id("action"), action, app, result, createdAt: Date.now() }; await write(KEYS.actions, [item, ...(await read<ActionLog[]>(KEYS.actions, []))].slice(0, LIMITS.actions)); return item; }
export async function listActions() { return read<ActionLog[]>(KEYS.actions, []); }

function cacheKey(input: string) { let hash = 2166136261; for (const char of input) { hash ^= char.charCodeAt(0); hash = Math.imul(hash, 16777619); } return String(hash >>> 0); }
export async function getCachedResponse(input: string, maxAgeMs = 7 * 24 * 60 * 60 * 1000) { const cache = await read<Record<string, CacheItem>>(KEYS.cache, {}); const item = cache[cacheKey(input)]; return item && Date.now() - item.createdAt < maxAgeMs ? item.value : null; }
export async function cacheResponse(input: string, value: string) { const cache = await read<Record<string, CacheItem>>(KEYS.cache, {}); const entries = Object.entries({ ...cache, [cacheKey(input)]: { value, createdAt: Date.now() } }).slice(-LIMITS.cache); await write(KEYS.cache, Object.fromEntries(entries)); }

export function parseRememberCommand(text: string) { const match = text.match(/^запомни(?:,|\s+что)?\s+(.+)$/i); return match?.[1]?.trim() ?? null; }
export function parseNoteCommand(text: string) { const match = text.match(/^(?:создай заметку|сохрани заметку|заметка)\s*:?[ ]*(.+)$/i); return match?.[1]?.trim() ?? null; }
export function parseMemorySearchCommand(text: string) { const match = text.match(/^(?:найди в памяти|что я говорил про|поищи заметку)\s+(.+)$/i); return match?.[1]?.trim() ?? null; }
