import type { WhisperModel, WakeWordHandlers } from "@/lib/offline-speech";

export async function startNativeWhisperWakeService(_model: WhisperModel, _handlers: WakeWordHandlers): Promise<void> {
  throw new Error("Native Whisper implementation is selected by the platform bundler.");
}

export async function stopNativeWhisperWakeService(): Promise<void> {
  return undefined;
}
