import type { WhisperModel, WakeWordHandlers } from "@/lib/offline-speech";

export async function startNativeWhisperWakeService(_model: WhisperModel, _handlers: WakeWordHandlers): Promise<void> {
  throw new Error("Offline Whisper wake word работает только в native Android APK, не в браузерном Preview.");
}

export async function stopNativeWhisperWakeService(): Promise<void> {
  return undefined;
}
