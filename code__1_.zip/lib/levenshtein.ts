export function normalizeCommand(value: string): string {
  return value
    .toLocaleLowerCase("ru-RU")
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Returns the minimum number of single-character edits needed to transform a into b. */
export function levenshteinDistance(a: string, b: string): number {
  const left = Array.from(a);
  const right = Array.from(b);
  if (left.length === 0) return right.length;
  if (right.length === 0) return left.length;

  let previous = Array.from({ length: right.length + 1 }, (_, index) => index);
  for (let row = 1; row <= left.length; row += 1) {
    const current = [row];
    for (let column = 1; column <= right.length; column += 1) {
      const insertion = current[column - 1] + 1;
      const deletion = previous[column] + 1;
      const substitution = previous[column - 1] + (left[row - 1] === right[column - 1] ? 0 : 1);
      current[column] = Math.min(insertion, deletion, substitution);
    }
    previous = current;
  }
  return previous[right.length];
}

export function normalizedDistance(a: string, b: string): number {
  const left = normalizeCommand(a);
  const right = normalizeCommand(b);
  const denominator = Math.max(Array.from(left).length, Array.from(right).length, 1);
  return levenshteinDistance(left, right) / denominator;
}

export function bestFuzzyMatch<T extends { label: string; aliases?: string[] }>(value: string, candidates: T[], threshold = 0.38): T | null {
  const normalized = normalizeCommand(value);
  if (!normalized) return null;
  let best: { candidate: T; score: number } | null = null;
  for (const candidate of candidates) {
    for (const phrase of [candidate.label, ...(candidate.aliases ?? [])]) {
      const score = normalizedDistance(normalized, phrase);
      if (!best || score < best.score) best = { candidate, score };
    }
  }
  return best && best.score <= threshold ? best.candidate : null;
}
