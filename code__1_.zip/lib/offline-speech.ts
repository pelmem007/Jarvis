import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import { Directory, File, Paths } from "expo-file-system";

export type WhisperModel = { id: string; name: string; uri: string; sizeBytes: number; importedAt: number };
export type WakeWordHandlers = { onWakeWord: () => void; onCommand: (text: string) => void; onError?: (message: string) => void };

const MODELS_KEY = "jarvis.offline.whisper.models.v1";

function modelDirectory() {
  const directory = new Directory(Paths.document, "jarvis-whisper-models");
  if (!directory.exists) directory.create({ intermediates: true, idempotent: true });
  return directory;
}

function safeFileName(name: string) {
  const clean = name.replace(/[^a-zA-Z0-9._-]/g, "-");
  return clean.toLowerCase().endsWith(".bin") || clean.toLowerCase().endsWith(".gguf") ? clean : `${clean}.bin`;
}

export async function loadStoredWhisperModels(): Promise<WhisperModel[]> {
  try {
    const raw = await AsyncStorage.getItem(MODELS_KEY);
    return raw ? (JSON.parse(raw) as WhisperModel[]) : [];
  } catch {
    return [];
  }
}

export async function pickAndRegisterWhisperModel(): Promise<WhisperModel | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["application/octet-stream", "*/*"], copyToCacheDirectory: true, multiple: false, base64: false });
  if (result.canceled || !result.assets?.[0]) return null;
  const asset = result.assets[0];
  const lowerName = asset.name.toLowerCase();
  if (!lowerName.endsWith(".bin") && !lowerName.endsWith(".gguf")) throw new Error("Выберите Whisper-модель .bin или .gguf");
  const destination = new File(modelDirectory(), `${Date.now()}-${safeFileName(asset.name)}`);
  await new File(asset.uri).copy(destination);
  const model: WhisperModel = { id: destination.uri, name: asset.name, uri: destination.uri, sizeBytes: destination.size || asset.size || 0, importedAt: Date.now() };
  const stored = (await loadStoredWhisperModels()).filter((item) => item.uri !== model.uri);
  await AsyncStorage.setItem(MODELS_KEY, JSON.stringify([model, ...stored]));
  return model;
}

export async function startWhisperWakeService(model: WhisperModel, handlers: WakeWordHandlers) {
  const { startNativeWhisperWakeService } = await import("./offline-speech-native");
  return startNativeWhisperWakeService(model, handlers);
}

export async function stopWhisperWakeService() {
  const { stopNativeWhisperWakeService } = await import("./offline-speech-native");
  return stopNativeWhisperWakeService();
}

export function formatWhisperModelSize(sizeBytes: number) {
  if (!sizeBytes) return "размер неизвестен";
  if (sizeBytes < 1024 * 1024) return `${Math.round(sizeBytes / 1024)} KB`;
  return `${(sizeBytes / (1024 * 1024)).toFixed(sizeBytes < 128 * 1024 * 1024 ? 1 : 0)} MB`;
}
