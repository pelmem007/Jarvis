import { Platform } from "react-native";
import { bestFuzzyMatch, normalizeCommand } from "@/lib/levenshtein";
import type { WhisperModel, WakeWordHandlers } from "@/lib/offline-speech";

let stopActiveListener: (() => Promise<void>) | null = null;
let activeTask: Promise<void> | null = null;

function isWakeWord(text: string) {
  const normalized = normalizeCommand(text);
  if (normalized.includes("джарвис")) return true;
  const words = normalized.split(" ").filter(Boolean);
  const candidates = [{ label: "джарвис", aliases: ["джарвес", "джарви", "джарвис"] }];
  return words.some((word) => bestFuzzyMatch(word, candidates, 0.45) !== null);
}

async function createRealtimeListener(model: WhisperModel, handlers: WakeWordHandlers) {
  const { initWhisper } = await import("whisper.rn");
  const { RealtimeTranscriber } = await import("whisper.rn/realtime-transcription");
  const { AudioPcmStreamAdapter } = await import("whisper.rn/realtime-transcription/adapters");
  const whisperContext = await initWhisper({ filePath: model.uri, useGpu: true, useFlashAttn: true });
  const audioStream = new AudioPcmStreamAdapter();
  let armedUntil = 0;
  let stopped = false;
  const transcriber = new RealtimeTranscriber(
    { whisperContext, audioStream },
    { audioSliceSec: 1.8, audioMinSec: 1, maxSlicesInMemory: 3, promptPreviousSlices: false, realtimeProcessingPauseMs: 120, audioStreamConfig: { sampleRate: 16000, channels: 1, bitsPerSample: 16, bufferSize: 16 * 1024 }, transcribeOptions: { language: "ru", translate: false, maxThreads: 4, temperature: 0 } },
    {
      onTranscribe: (event: { data?: { result?: string } }) => {
        const text = event.data?.result?.trim();
        if (!text || stopped) return;
        if (armedUntil > Date.now()) { armedUntil = 0; handlers.onCommand(text); return; }
        if (isWakeWord(text)) { armedUntil = Date.now() + 8000; handlers.onWakeWord(); }
      },
      onError: (message: string) => handlers.onError?.(message),
    },
  );
  await transcriber.start();
  return async () => { stopped = true; await transcriber.stop(); await audioStream.release(); await whisperContext.release(); };
}

const sleep = (milliseconds: number) => new Promise((resolve) => setTimeout(resolve, milliseconds));

export async function startNativeWhisperWakeService(model: WhisperModel, handlers: WakeWordHandlers) {
  if (Platform.OS === "web") throw new Error("Wake word service доступен только в native Android/iOS сборке.");
  if (stopActiveListener || activeTask) return;
  const BackgroundService = (await import("react-native-background-actions")).default;
  const task = async () => {
    try {
      stopActiveListener = await createRealtimeListener(model, handlers);
      while (BackgroundService.isRunning()) await sleep(1000);
    } catch (error) {
      handlers.onError?.(error instanceof Error ? error.message : "Whisper listener завершился с ошибкой.");
    } finally {
      await stopActiveListener?.();
      stopActiveListener = null;
    }
  };
  activeTask = BackgroundService.start(task, { taskName: "JarvisWakeWord", taskTitle: "JARVIS слушает", taskDesc: "Оффлайн wake word «Джарвис» активен", taskIcon: { name: "icon", type: "mipmap" }, color: "#76F7FF", linkingURI: "manus://jarvis", foregroundServiceType: ["microphone"], parameters: { model: model.name } }).finally(() => { activeTask = null; });
  await activeTask;
}

export async function stopNativeWhisperWakeService() {
  const BackgroundService = (await import("react-native-background-actions")).default;
  await stopActiveListener?.();
  stopActiveListener = null;
  if (BackgroundService.isRunning()) await BackgroundService.stop();
  activeTask = null;
}
