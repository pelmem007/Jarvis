import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

export async function requestAutomationPermission() {
  if (Platform.OS === "web") return false;
  if (Platform.OS === "android") await Notifications.setNotificationChannelAsync("jarvis-reminders", { name: "JARVIS reminders", importance: Notifications.AndroidImportance.DEFAULT });
  const current = await Notifications.getPermissionsAsync();
  if (current.status === "granted") return true;
  return (await Notifications.requestPermissionsAsync()).status === "granted";
}

export async function scheduleReminder(text: string, minutesFromNow: number) {
  if (!(await requestAutomationPermission())) throw new Error("NOTIFICATIONS_PERMISSION_REQUIRED");
  const id = await Notifications.scheduleNotificationAsync({ content: { title: "JARVIS · Напоминание", body: text, data: { source: "jarvis-local-reminder" } }, trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: Math.max(10, minutesFromNow * 60), repeats: false } as any });
  return id;
}

export async function scheduleDailyReminder(text: string, hour: number, minute = 0, weekdaysOnly = false) {
  if (!(await requestAutomationPermission())) throw new Error("NOTIFICATIONS_PERMISSION_REQUIRED");
  const id = await Notifications.scheduleNotificationAsync({ content: { title: "JARVIS · План", body: text, data: { source: "jarvis-daily-reminder", weekdaysOnly } }, trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour, minute, repeats: true } as any });
  return id;
}

export async function cancelAllReminders() { await Notifications.cancelAllScheduledNotificationsAsync(); }
export async function listScheduledReminders() { return Notifications.getAllScheduledNotificationsAsync(); }

export async function parseAndScheduleReminder(text: string) {
  const relative = text.match(/^напомни(?: мне)? через (\d+)\s*(минут|минуты|час|часа|часов)\s*(?:что)?\s*(.*)$/i);
  if (relative) { const amount = Number(relative[1]); const minutes = relative[2].startsWith("час") ? amount * 60 : amount; return scheduleReminder(relative[3] || "Пора проверить задачу", minutes); }
  const daily = text.match(/^каждый будний день в (\d{1,2})(?::(\d{2}))?\s*(.*)$/i);
  if (daily) return scheduleDailyReminder(daily[3] || "Проверьте планы на сегодня", Number(daily[1]), Number(daily[2] || 0), true);
  return null;
}
