import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import { Directory, File, Paths } from "expo-file-system";
import type { LlamaContext } from "llama.rn";
import { cacheResponse, getCachedResponse } from "@/lib/smart-memory";
import { JARVIS_LOW_MEMORY_PROFILE } from "@/lib/model-profile";

export type OfflineModel = {
  id: string;
  name: string;
  uri: string;
  sizeBytes: number;
  architecture?: string;
  importedAt: number;
};

const MODELS_KEY = "jarvis.offline.gguf.models.v1";
let activeContext: LlamaContext | null = null;
let activeModelId: string | null = null;

function modelDirectory() {
  const directory = new Directory(Paths.document, "jarvis-models");
  if (!directory.exists) directory.create({ intermediates: true, idempotent: true });
  return directory;
}

function safeFileName(name: string) {
  const clean = name.replace(/[^a-zA-Z0-9._-]/g, "-");
  return clean.toLowerCase().endsWith(".gguf") ? clean : `${clean}.gguf`;
}

export async function loadStoredOfflineModels(): Promise<OfflineModel[]> {
  try {
    const raw = await AsyncStorage.getItem(MODELS_KEY);
    return raw ? (JSON.parse(raw) as OfflineModel[]) : [];
  } catch {
    return [];
  }
}

async function saveModels(models: OfflineModel[]) {
  await AsyncStorage.setItem(MODELS_KEY, JSON.stringify(models));
}

export async function pickAndRegisterGgufModel(): Promise<OfflineModel | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["application/octet-stream", "*/*"], copyToCacheDirectory: true, multiple: false, base64: false });
  if (result.canceled || !result.assets?.[0]) return null;
  const asset = result.assets[0];
  if (!asset.name.toLowerCase().endsWith(".gguf")) throw new Error("Выберите файл с расширением .gguf");

  const destination = new File(modelDirectory(), `${Date.now()}-${safeFileName(asset.name)}`);
  await new File(asset.uri).copy(destination);
  let architecture: string | undefined;
  if (PlatformIsNative()) {
    try {
      const { loadLlamaModelInfo } = await import("llama.rn");
      const info = await loadLlamaModelInfo(destination.uri) as { general_architecture?: string; general_name?: string };
      architecture = info.general_architecture ?? info.general_name;
    } catch {
      architecture = undefined;
    }
  }

  const model: OfflineModel = { id: destination.uri, name: asset.name, uri: destination.uri, sizeBytes: destination.size || asset.size || 0, architecture, importedAt: Date.now() };
  const models = (await loadStoredOfflineModels()).filter((item) => item.uri !== model.uri);
  await saveModels([model, ...models]);
  return model;
}

function PlatformIsNative() {
  return typeof navigator === "undefined" || navigator.product === "ReactNative";
}

export async function completeWithOfflineModel(model: OfflineModel, history: Array<{ role: "user" | "assistant"; text: string }>, message: string): Promise<string> {
  if (!PlatformIsNative()) throw new Error("Offline GGUF runtime доступен только в native Android/iOS сборке.");
  const cacheInput = `${model.id}|${JSON.stringify(history.slice(-4))}|${message.trim()}`;
  const cached = await getCachedResponse(cacheInput, JARVIS_LOW_MEMORY_PROFILE.cacheTtlMs);
  if (cached) return cached;
  const llama = await import("llama.rn");
  if (!activeContext || activeModelId !== model.id) {
    if (activeContext) await activeContext.release();
    activeContext = await llama.initLlama({
      model: model.uri,
      use_mlock: false,
      n_ctx: JARVIS_LOW_MEMORY_PROFILE.maxContext,
      n_batch: JARVIS_LOW_MEMORY_PROFILE.batch,
      n_ubatch: JARVIS_LOW_MEMORY_PROFILE.batch,
      n_parallel: 1,
      n_threads: JARVIS_LOW_MEMORY_PROFILE.threads,
      n_gpu_layers: JARVIS_LOW_MEMORY_PROFILE.gpuLayers,
      cache_type_k: "q8_0",
      cache_type_v: "q8_0",
      flash_attn_type: "off",
    });
    activeModelId = model.id;
  }
  const result = await activeContext.completion({
    messages: [
      { role: "system", content: "Ты JARVIS — локальный offline-ассистент. Отвечай на русском кратко, точно и без выдуманных действий." },
      ...history.map((item) => ({ role: item.role, content: item.text })),
      { role: "user", content: message },
    ],
    n_predict: JARVIS_LOW_MEMORY_PROFILE.maxTokens,
    temperature: JARVIS_LOW_MEMORY_PROFILE.temperature,
    top_p: JARVIS_LOW_MEMORY_PROFILE.topP,
    stop: ["</s>", "<|end|>", "<|eot_id|>", "<|im_end|>"],
  });
  const text = result.text?.trim();
  if (!text) throw new Error("Offline GGUF не вернула текстовый ответ");
  await cacheResponse(cacheInput, text);
  return text;
}

export async function releaseOfflineModel() {
  if (activeContext) await activeContext.release();
  activeContext = null;
  activeModelId = null;
}

export function formatModelSize(sizeBytes: number) {
  if (!sizeBytes) return "размер неизвестен";
  if (sizeBytes < 1024 * 1024) return `${Math.round(sizeBytes / 1024)} KB`;
  return `${(sizeBytes / (1024 * 1024)).toFixed(sizeBytes < 128 * 1024 * 1024 ? 1 : 0)} MB`;
}
