export const JARVIS_LOW_MEMORY_PROFILE = {
  label: "Qwen2.5-1.5B-Instruct Q4_K_M",
  fallbackLabel: "Qwen2.5-0.5B-Instruct Q4_K_M · FAST",
  maxContext: 2048,
  batch: 128,
  maxTokens: 160,
  temperature: 0.35,
  topP: 0.85,
  gpuLayers: 0,
  threads: 4,
  cacheTtlMs: 7 * 24 * 60 * 60 * 1000,
  maxStoredNotes: 200,
  maxStoredMemories: 100,
  maxActionLog: 300,
  rationale: "CPU-first для Unisoc/T7250; GPU offload не считается подтверждённым."
} as const;
